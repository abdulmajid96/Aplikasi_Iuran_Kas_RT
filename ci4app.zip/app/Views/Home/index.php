
<style>
  h3 {
    color: #0275d8;
    text-align: center;
  }

</style>
<h3>Selamat datang di Sistem Iuran KAS RT</h3>
<h3>Sistem ini dibuat untuk mengikuti UAS Matkul Pemrograman WEB</h3>
<h3>Universitas Pelita Bangsa | Abdul Majid (311810693)</h3>
