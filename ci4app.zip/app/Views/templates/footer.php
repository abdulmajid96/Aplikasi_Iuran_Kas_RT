</div>
</div>
</div>
</body>
<script src="<?=base_url();?>/assets/global/js/jquery-3.4.1.js"></script>
<script src="<?=base_url();?>/assets/global/js/popper.min.js"></script>
<script src="<?=base_url();?>/assets/global/js/bootstrap.min.js"></script>

<?= $this->renderSection('extra-js') ?>

</html>
